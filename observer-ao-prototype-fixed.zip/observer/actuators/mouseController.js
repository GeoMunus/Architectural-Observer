mouse.move(x, y);
mouse.click();
mouse.doubleClick();
mouse.rightClick();
mouse.drag(x, y);
mouse.scroll(amount);