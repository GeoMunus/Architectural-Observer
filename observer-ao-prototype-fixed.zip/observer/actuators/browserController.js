await browser.open("https://google.com");
await browser.newTab();
await browser.closeTab();
await browser.back();
await browser.forward();
await browser.refresh();