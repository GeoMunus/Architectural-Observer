export class Goal {

    constructor(name) {

        this.name = name;

        this.criteria = [];

    }

    addCriterion(fn) {

        this.criteria.push(fn);

    }

    evaluate(event) {

        let score = 0;

        for (const criterion of this.criteria) {

            score += criterion(event);

        }

        return Math.min(score,1);

    }

}