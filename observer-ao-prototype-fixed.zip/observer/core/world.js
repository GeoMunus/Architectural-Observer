export class World {
    constructor() {
        this.objects = [];
        this.events = [];
        this.memories = [];
        this.concepts = [];
        this.patterns = [];
        this.thoughts = [];
        this.goals = [];
        this.questions = [];
        this.cautions = [];
        this.actions = [];
        this.timeline = [];
        this.text = [];
        this.cycle = 0;
        this.lastUpdated = 0;
        this.telemetry = {
            averageConfidence: 0,
            averageImportance: 0,
            signalStrength: 0,
            motionScore: 0
        };
        this.context = {
            scenario: "",
            mode: "webpage"
        };
    }
}
