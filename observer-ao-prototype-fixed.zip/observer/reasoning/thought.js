export default class Thought {

    constructor(type, message, priority = 50, data = {}) {

        this.type = type;

        this.message = message;

        this.priority = priority;

        this.data = data;

        this.created = Date.now();

    }

}