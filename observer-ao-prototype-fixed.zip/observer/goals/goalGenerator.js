for (const thought of thoughts) {

    switch (thought.type) {

        case "loginScreen":

            goalManager.add({

                type: "understandLogin",

                target: thought.data,

                priority: thought.priority

            });

            break;

    }

}