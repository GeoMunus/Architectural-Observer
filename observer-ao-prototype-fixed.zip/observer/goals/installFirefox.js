const installFirefox = new Goal("Install Firefox");

installFirefox.addCriterion(event => {

    if(event.type === "Download")
        return 0.6;

    return 0;

});

installFirefox.addCriterion(event => {

    if(event.type === "RunInstaller")
        return 0.4;

    return 0;

});