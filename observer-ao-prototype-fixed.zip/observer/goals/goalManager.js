import Goal from "./goal.js";

export default class GoalManager {

    constructor() {

        this.goals = [];

    }

    add(goalData) {

        this.goals.push(

            new Goal(
                goalData.type,
                goalData.target,
                goalData.priority
            )

        );

    }

    getHighestPriority() {

        this.goals.sort((a, b) => b.priority - a.priority);

        return this.goals[0];

    }

    complete(goal) {

        goal.status = "complete";

    }

}