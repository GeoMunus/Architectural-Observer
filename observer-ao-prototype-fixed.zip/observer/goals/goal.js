export default class Goal {

    constructor(type, target, priority) {

        this.type = type;
        this.target = target;

        this.priority = priority;

        this.status = "pending";

        this.plan = null;

    }

}