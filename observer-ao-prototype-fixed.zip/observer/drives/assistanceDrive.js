import Drive from "./drive.js";

export default class AssistanceDrive extends Drive {

    constructor() {
        super("Assistance", 90);
    }

    evaluate(world) {

        const goals = [];

        if (world.userRequest) {

            goals.push({
                type: "helpUser",
                target: world.userRequest,
                priority: 100
            });

        }

        return goals;

    }

}