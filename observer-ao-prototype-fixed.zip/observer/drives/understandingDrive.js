import Drive from "./drive.js";

export default class UnderstandingDrive extends Drive {

    constructor() {
        super("Understanding", 80);
    }

    evaluate(world) {

        const goals = [];

        for (const conflict of world.conflicts) {

            goals.push({
                type: "resolveConflict",
                target: conflict.id,
                priority: this.priority + 10
            });

        }

        return goals;
    }

}