export default class Drive {
    constructor(name, priority = 50) {
        this.name = name;
        this.priority = priority;
    }

    evaluate(world) {
        // Override in child drives
        return [];
    }
}