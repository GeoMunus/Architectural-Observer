import CuriosityDrive from "./curiosityDrive.js";
import UnderstandingDrive from "./understandingDrive.js";
import AssistanceDrive from "./assistanceDrive.js";

export default class DriveManager {

    constructor() {

        this.drives = [

            new CuriosityDrive(),
            new UnderstandingDrive(),
            new AssistanceDrive()

        ];

    }

    generateGoals(world) {

        let goals = [];

        for (const drive of this.drives) {

            goals.push(...drive.evaluate(world));

        }

        return goals;

    }

}