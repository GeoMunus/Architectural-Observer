import { BaseAgent } from "./baseAgent.js";

export class CuriosityAgent extends BaseAgent {
    constructor() {
        super("Curiosity");
    }

    update(world) {
        const questions = [];

        if (world.context.mode !== "screen") {
            questions.push("Would full-screen vision reveal adjacent tools or architectural context outside this prototype window?");
        }

        if (world.patterns.length < 3) {
            questions.push("Are there enough repeated structures to identify stable subsystems yet?");
        }

        if ((world.context.scenario || "").trim().length === 0) {
            questions.push("What mission or architecture should Observer AO optimize for next?");
        }

        if (world.objects.some((obj) => obj.type === "INPUT")) {
            questions.push("Which inputs are operational controls versus passive telemetry fields?");
        }

        world.questions = questions.slice(0, 4);
    }
}
