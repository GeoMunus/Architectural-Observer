import { BaseAgent } from "./baseAgent.js";

export class ActionAgent extends BaseAgent {
    constructor() {
        super("Action");
    }

    update(world) {
        const actions = [];

        if (world.goals[0]) {
            actions.push(`Prioritize: ${world.goals[0].title}`);
        }

        if (world.context.mode !== "screen") {
            actions.push("Enable full-screen vision to expand architectural coverage.");
        }

        if (world.patterns[0]) {
            actions.push(`Inspect strongest pattern: ${world.patterns[0].name}.`);
        }

        if (world.questions[0]) {
            actions.push(`Resolve open question: ${world.questions[0]}`);
        }

        world.actions = actions.slice(0, 4);
    }
}
