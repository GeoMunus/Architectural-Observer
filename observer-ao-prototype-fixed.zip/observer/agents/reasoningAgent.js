import { BaseAgent } from "./baseAgent.js";

export class ReasoningAgent extends BaseAgent {
    constructor() {
        super("Reasoning");
    }

    update(world) {
        const thoughts = [];
        const objectCount = world.objects.length;
        const hasInteractiveDensity = world.patterns.some((pattern) => pattern.name.includes("BUTTON") || pattern.name.includes("Button") || pattern.name.includes("INPUT") || pattern.name.includes("Input"));
        const recentEvents = world.events.map((event) => event.type);

        if (world.context.mode === "screen") {
            thoughts.push({
                id: "thought-screen-mode",
                type: "situational-awareness",
                message: "Observer is reading the entire screen, so the prototype can reason over ambient activity instead of only its own UI.",
                priority: 86
            });
        }

        if (objectCount >= 12) {
            thoughts.push({
                id: "thought-dense-ui",
                type: "interface-density",
                message: `The scene is dense with ${objectCount} recognizable interface signals, which is enough to infer architectural hotspots.`,
                priority: 78
            });
        }

        if (hasInteractiveDensity) {
            thoughts.push({
                id: "thought-control-cluster",
                type: "interaction-surface",
                message: "Controls are clustered around a few dominant interaction surfaces, suggesting a central orchestration panel.",
                priority: 72
            });
        }

        if (recentEvents.includes("InterfaceChanged")) {
            thoughts.push({
                id: "thought-layout-change",
                type: "change-detection",
                message: "The observed structure changed between cycles, so the system should capture a fresh architectural snapshot.",
                priority: 84
            });
        }

        if (world.context.scenario) {
            thoughts.push({
                id: "thought-scenario-focus",
                type: "mission-focus",
                message: `Current mission focus: ${world.context.scenario.slice(0, 140)}`,
                priority: 68
            });
        }

        if (thoughts.length === 0) {
            thoughts.push({
                id: "thought-baseline",
                type: "baseline",
                message: "Signals are stable. Observer AO can continue collecting evidence before escalating any architectural interpretation.",
                priority: 50
            });
        }

        world.thoughts = thoughts.sort((a, b) => b.priority - a.priority).slice(0, 6);
    }
}
