import { BaseAgent } from "./baseAgent.js";
import { Thing } from "../core/thing.js";
import { Event } from "../core/event.js";

export class VisionAgent extends BaseAgent {
    constructor(root = document.body) {
        super("Vision");
        this.root = root;
        this.bound = false;
        this.interactionQueue = [];
        this.screenMode = false;
        this.screenStream = null;
        this.video = document.createElement("video");
        this.video.muted = true;
        this.video.playsInline = true;
        this.video.autoplay = true;
        this.canvas = document.createElement("canvas");
        this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
        this.previousSample = null;
        this.systemQueue = [];
        this.lastPointCount = 0;
        this.lastMotionScore = 0;
    }

    clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }

    async startScreenCapture() {
        if (!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)) {
            throw new Error("Screen capture is not supported in this browser.");
        }

        const stream = await navigator.mediaDevices.getDisplayMedia({
            video: {
                displaySurface: "monitor",
                cursor: "always",
                frameRate: { ideal: 12, max: 20 }
            },
            audio: false
        });

        this.screenStream = stream;
        this.video.srcObject = stream;
        await this.video.play();
        this.screenMode = true;
        this.previousSample = null;

        const [track] = stream.getVideoTracks();
        if (track) {
            track.addEventListener("ended", () => {
                this.stopScreenCapture();
                this.systemQueue.push({
                    type: "ScreenCaptureStopped",
                    data: { reason: "user-ended" }
                });
            });
        }

        this.systemQueue.push({
            type: "ScreenCaptureStarted",
            data: {}
        });
    }

    stopScreenCapture() {
        if (this.screenStream) {
            for (const track of this.screenStream.getTracks()) {
                track.stop();
            }
        }

        this.screenStream = null;
        this.video.srcObject = null;
        this.screenMode = false;
        this.previousSample = null;
        this.lastPointCount = 0;
        this.lastMotionScore = 0;
    }

    getVisionInfo() {
        const track = this.screenStream?.getVideoTracks?.()[0];
        const settings = track?.getSettings ? track.getSettings() : {};

        return {
            screenMode: this.screenMode,
            displaySurface: settings.displaySurface || "unknown",
            width: settings.width || this.video.videoWidth || 0,
            height: settings.height || this.video.videoHeight || 0,
            pointCount: this.lastPointCount,
            motionScore: this.lastMotionScore
        };
    }

    analyzeScreen(world) {
        if (!this.ctx) return;
        if (this.video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) return;

        const sourceWidth = this.video.videoWidth || 0;
        const sourceHeight = this.video.videoHeight || 0;
        if (sourceWidth === 0 || sourceHeight === 0) return;

        const sampleWidth = 192;
        const sampleHeight = 108;
        this.canvas.width = sampleWidth;
        this.canvas.height = sampleHeight;

        this.ctx.drawImage(this.video, 0, 0, sampleWidth, sampleHeight);
        const imageData = this.ctx.getImageData(0, 0, sampleWidth, sampleHeight);
        const data = imageData.data;

        let totalLuma = 0;
        let diff = 0;
        let count = 0;

        for (let i = 0; i < data.length; i += 4) {
            const luma = (0.299 * data[i]) + (0.587 * data[i + 1]) + (0.114 * data[i + 2]);
            totalLuma += luma;
            if (this.previousSample) {
                diff += Math.abs(luma - this.previousSample[count]);
            }
            count += 1;
        }

        const averageLuma = totalLuma / count;
        const averageDiff = this.previousSample ? diff / count : 0;
        this.lastMotionScore = Number(averageDiff.toFixed(2));
        this.previousSample = new Float32Array(count);

        for (let i = 0, idx = 0; i < data.length; i += 4, idx += 1) {
            this.previousSample[idx] = (0.299 * data[i]) + (0.587 * data[i + 1]) + (0.114 * data[i + 2]);
        }

        world.objects.push(new Thing("Screen", {
            text: "Full-screen capture",
            width: sourceWidth,
            height: sourceHeight,
            averageLuma: Number(averageLuma.toFixed(2)),
            motionScore: this.lastMotionScore
        }));

        const gridCols = this.clamp(Math.round(sourceWidth / 180), 8, 18);
        const gridRows = this.clamp(Math.round(sourceHeight / 180), 5, 12);
        const cellWidth = sampleWidth / gridCols;
        const cellHeight = sampleHeight / gridRows;

        for (let row = 0; row < gridRows; row += 1) {
            for (let col = 0; col < gridCols; col += 1) {
                const sampleX = Math.min(sampleWidth - 1, Math.floor((col + 0.5) * cellWidth));
                const sampleY = Math.min(sampleHeight - 1, Math.floor((row + 0.5) * cellHeight));
                const pixelIndex = (sampleY * sampleWidth + sampleX) * 4;
                const r = data[pixelIndex];
                const g = data[pixelIndex + 1];
                const b = data[pixelIndex + 2];
                const luma = (0.299 * r) + (0.587 * g) + (0.114 * b);

                world.objects.push(new Thing("ScreenPoint", {
                    text: `Zone ${row + 1}-${col + 1}`,
                    x: Math.round((sampleX / sampleWidth) * sourceWidth),
                    y: Math.round((sampleY / sampleHeight) * sourceHeight),
                    brightness: Number(luma.toFixed(2))
                }));
            }
        }

        this.lastPointCount = gridCols * gridRows;
        world.telemetry.motionScore = this.lastMotionScore;

        if (averageDiff > 6) {
            world.events.push(new Event("ScreenChanged", {
                motionScore: this.lastMotionScore
            }));
        }

        world.events.push(new Event("ScreenPointsUpdated", {
            points: this.lastPointCount,
            width: sourceWidth,
            height: sourceHeight
        }));
    }

    bindEvents() {
        if (this.bound) return;

        this.root.addEventListener("click", (event) => {
            const target = event.target;
            if (!(target instanceof Element)) return;
            this.interactionQueue.push({
                type: "Click",
                data: {
                    tag: target.tagName,
                    id: target.id || "",
                    className: target.className || "",
                    text: (target.textContent || "").trim().slice(0, 60)
                }
            });
        });

        this.root.addEventListener("input", (event) => {
            const target = event.target;
            if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) return;
            this.interactionQueue.push({
                type: "Input",
                data: {
                    tag: target.tagName,
                    id: target.id || "",
                    valueLength: target.value.length
                }
            });
        });

        window.addEventListener("scroll", () => {
            this.interactionQueue.push({
                type: "Scroll",
                data: {
                    y: Math.round(window.scrollY)
                }
            });
        }, { passive: true });

        this.bound = true;
    }

    collectDomObjects(world) {
        const selectors = [
            "button",
            "input",
            "textarea",
            "select",
            "a",
            "section",
            "article",
            "h1",
            "h2",
            "[data-agent-card]",
            "[data-list-panel]"
        ];

        const candidates = this.root.querySelectorAll(selectors.join(","));
        const textSignals = [];

        for (const element of candidates) {
            const text = (element.textContent || element.getAttribute("aria-label") || "").trim().replace(/\s+/g, " ").slice(0, 80);
            if (text.length > 0) {
                textSignals.push(text);
            }

            world.objects.push(new Thing(element.tagName, {
                text,
                id: element.id || "",
                className: element.className || "",
                role: element.getAttribute("role") || "",
                disabled: "disabled" in element ? Boolean(element.disabled) : false
            }));
        }

        world.text = textSignals.slice(0, 40);
    }

    update(world) {
        this.bindEvents();
        world.objects = [];
        world.text = [];
        world.context.mode = this.screenMode ? "screen" : "webpage";

        if (this.screenMode) {
            this.analyzeScreen(world);
        } else {
            this.collectDomObjects(world);
            world.telemetry.motionScore = 0;
        }

        while (this.systemQueue.length > 0) {
            const item = this.systemQueue.shift();
            world.events.push(new Event(item.type, item.data));
        }

        while (this.interactionQueue.length > 0) {
            const item = this.interactionQueue.shift();
            world.events.push(new Event(item.type, item.data));
        }
    }
}
