export class GoalAgent {

    constructor() {

        this.currentGoal = null;

    }

    setGoal(goal) {

        this.currentGoal = goal;

    }

    update(world) {

        if (!this.currentGoal) return;

        for (const event of world.events) {

            event.goalRelevance =
                this.calculateRelevance(event);

        }

    }

    calculateRelevance(event) {

        return this.currentGoal.evaluate(event);

    }

}