import { BaseAgent } from "./baseAgent.js";

export class SkepticAgent extends BaseAgent {
    constructor() {
        super("Skeptic");
    }

    update(world) {
        const cautions = [];

        if (world.context.mode !== "screen") {
            cautions.push("Current visibility is limited to the prototype DOM, so hidden windows and off-screen systems are not part of this model.");
        }

        if (world.telemetry.averageConfidence < 0.55 && world.memories.length > 0) {
            cautions.push("Memory confidence is still moderate; avoid overfitting conclusions from a small number of snapshots.");
        }

        if (world.events.some((event) => event.type === "InterfaceChanged")) {
            cautions.push("Recent interface change detected; prior inferences may already be stale.");
        }

        if (world.patterns.length === 0) {
            cautions.push("No durable patterns are visible yet, so architecture narratives remain provisional.");
        }

        world.cautions = cautions.slice(0, 4);
    }
}
