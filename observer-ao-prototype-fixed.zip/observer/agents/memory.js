export class MemoryAgent {

    update(world){

        if(world.events.length === 0) return;

        const memory = {

            objects: [...world.objects],

            events: [...world.events],

            confidence:1,

            success:false

        };

        world.addMemory(memory);

        world.events = [];

    }

}
