export class ImportanceAgent {

    update(world) {

        for(const event of world.events){

            event.importance =

                this.goal(event)

                + this.novelty(world,event)

                + this.success(world,event)

                + this.frequency(world,event)

                + this.surprise(event);

        }

    }

    goal(event){

        return event.goalRelevance * 5;

    }

    novelty(world,event){

        return world.hasSeen(event) ? 0 : 3;

    }

    success(world,event){

        return world.successRatio(event) * 2;

    }

    frequency(world,event){

        return world.frequency(event);

    }

    surprise(event){

        return event.unexpected ? 2 : 0;

    }

}