import { World } from "./core/world.js";
import { VisionAgent } from "./agents/visionAgent.js";
import { EventAgent } from "./agents/eventAgent.js";
import { MemoryAgent } from "./agents/memoryAgent.js";
import { PatternAgent } from "./agents/patternAgent.js";
import { ConceptAgent } from "./agents/conceptAgent.js";
import { ReasoningAgent } from "./agents/reasoningAgent.js";
import { PlanningAgent } from "./agents/planningAgent.js";
import { CuriosityAgent } from "./agents/curiosityAgent.js";
import { SkepticAgent } from "./agents/skepticAgent.js";
import { ActionAgent } from "./agents/actionAgent.js";

const STORAGE_KEY = "observer.ao.snapshot.v2";
const MAX_TIMELINE = 30;

const world = new World();
const visionAgent = new VisionAgent(document.body);
const eventAgent = new EventAgent();
const memoryAgent = new MemoryAgent();
const patternAgent = new PatternAgent();
const conceptAgent = new ConceptAgent();
const reasoningAgent = new ReasoningAgent();
const planningAgent = new PlanningAgent();
const curiosityAgent = new CuriosityAgent();
const skepticAgent = new SkepticAgent();
const actionAgent = new ActionAgent();

const agents = [
    visionAgent,
    eventAgent,
    memoryAgent,
    patternAgent,
    conceptAgent,
    reasoningAgent,
    planningAgent,
    curiosityAgent,
    skepticAgent,
    actionAgent
];

const laneDefinitions = [
    { key: "vision", label: "Vision", description: "Senses the interface or full screen.", source: () => `${world.objects.length} objects · ${world.context.mode}` },
    { key: "memory", label: "Memory", description: "Stores snapshots with confidence and importance.", source: () => `${world.memories.length} memories · avg confidence ${world.telemetry.averageConfidence}` },
    { key: "pattern", label: "Pattern", description: "Extracts recurring structures and rhythms.", source: () => `${world.patterns.length} active patterns` },
    { key: "reasoning", label: "Reasoning", description: "Converts signals into architectural interpretation.", source: () => `${world.thoughts.length} thoughts · ${world.cautions.length} cautions` },
    { key: "planning", label: "Planning", description: "Ranks next best actions for the observer.", source: () => `${world.goals.length} goals · ${world.actions.length} actions` }
];

const elements = {
    objectsList: document.getElementById("objectsList"),
    eventsList: document.getElementById("eventsList"),
    memoriesList: document.getElementById("memoriesList"),
    conceptsList: document.getElementById("conceptsList"),
    patternsList: document.getElementById("patternsList"),
    goalsList: document.getElementById("goalsList"),
    actionsList: document.getElementById("actionsList"),
    timelineList: document.getElementById("timelineList"),
    graphSvg: document.getElementById("graphSvg"),
    agentLanes: document.getElementById("agentLanes"),
    selectedNodeLabel: document.getElementById("selectedNodeLabel"),
    selectedNodeType: document.getElementById("selectedNodeType"),
    selectedNodeDetail: document.getElementById("selectedNodeDetail"),
    visionStatus: document.getElementById("visionStatus"),
    scenarioInput: document.getElementById("scenarioInput"),
    modeBadge: document.getElementById("modeBadge"),
    cycleBadge: document.getElementById("cycleBadge"),
    signalBadge: document.getElementById("signalBadge"),
    objectsCount: document.getElementById("objectsCount"),
    eventsCount: document.getElementById("eventsCount"),
    memoriesCount: document.getElementById("memoriesCount"),
    conceptsCount: document.getElementById("conceptsCount"),
    thoughtsCount: document.getElementById("thoughtsCount"),
    goalsCount: document.getElementById("goalsCount"),
    startScreenVisionBtn: document.getElementById("startScreenVisionBtn"),
    stopScreenVisionBtn: document.getElementById("stopScreenVisionBtn"),
    checkVisionBtn: document.getElementById("checkVisionBtn"),
    exportMemoriesBtn: document.getElementById("exportMemoriesBtn"),
    importMemoriesBtn: document.getElementById("importMemoriesBtn"),
    importMemoriesInput: document.getElementById("importMemoriesInput"),
    runCycleBtn: document.getElementById("runCycleBtn"),
    autoCycleBtn: document.getElementById("autoCycleBtn"),
    loadSampleBtn: document.getElementById("loadSampleBtn"),
    clearBtn: document.getElementById("clearBtn"),
    chatMessages: document.getElementById("chatMessages"),
    chatInput: document.getElementById("chatInput"),
    sendChatBtn: document.getElementById("sendChatBtn")
};

const uiState = {
    autoTimer: null,
    selectedNodeId: ""
};

function sampleMission() {
    return "Observe this control cockpit as an architectural observer. Identify the main sensing surfaces, memory structures, recurring interaction patterns, reasoning outputs, and the next best actions for a human operator.";
}

function setVisionStatus(message) {
    if (elements.visionStatus) {
        elements.visionStatus.textContent = message;
    }
}

function compactText(value, max = 120) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function escapeHtml(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function snapshotForStorage() {
    return {
        version: 2,
        exportedAt: new Date().toISOString(),
        context: world.context,
        memories: world.memories,
        timeline: world.timeline,
        cycle: world.cycle,
        telemetry: world.telemetry,
        selectedNodeId: uiState.selectedNodeId,
        chatSeed: getRecentChatSeed()
    };
}

function persistSnapshot() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshotForStorage()));
    } catch {
        // Ignore storage failures.
    }
}

function loadSnapshot() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return null;
        return JSON.parse(raw);
    } catch {
        return null;
    }
}

function mergeImportedSnapshot(data) {
    if (Array.isArray(data)) {
        world.memories = data;
        world.timeline.unshift(createTimelineItem("import", "Imported legacy memory array", `${data.length} memories restored from an older export format.`));
        return;
    }

    const source = data?.world || data;
    if (!source || typeof source !== "object") return;

    world.context = {
        scenario: source.context?.scenario || source.scenario || world.context.scenario || "",
        mode: source.context?.mode || source.mode || "webpage"
    };
    world.memories = Array.isArray(source.memories) ? source.memories.slice(0, 60) : [];
    world.timeline = Array.isArray(source.timeline) ? source.timeline.slice(0, MAX_TIMELINE) : [];
    world.cycle = Number.isFinite(source.cycle) ? source.cycle : 0;
    world.telemetry = {
        averageConfidence: Number(source.telemetry?.averageConfidence || 0),
        averageImportance: Number(source.telemetry?.averageImportance || 0),
        signalStrength: Number(source.telemetry?.signalStrength || 0),
        motionScore: Number(source.telemetry?.motionScore || 0)
    };
    uiState.selectedNodeId = source.selectedNodeId || "";

    if (elements.scenarioInput) {
        elements.scenarioInput.value = world.context.scenario;
    }

    if (Array.isArray(source.chatSeed) && elements.chatMessages) {
        elements.chatMessages.innerHTML = "";
        for (const item of source.chatSeed.slice(-8)) {
            appendChatMessage(item.role, item.text, false);
        }
    }
}

function exportSnapshot() {
    const payload = JSON.stringify(snapshotForStorage(), null, 2);
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    link.href = url;
    link.download = `observer-ao-snapshot-${stamp}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

async function importSnapshot(file) {
    const text = await file.text();
    const parsed = JSON.parse(text);
    mergeImportedSnapshot(parsed);
    world.timeline.unshift(createTimelineItem("import", "Snapshot imported", "Prototype state, memories, and timeline were restored from file."));
    world.timeline = world.timeline.slice(0, MAX_TIMELINE);
    render();
    persistSnapshot();
}

function resetPrototype() {
    world.objects = [];
    world.events = [];
    world.memories = [];
    world.concepts = [];
    world.patterns = [];
    world.thoughts = [];
    world.goals = [];
    world.questions = [];
    world.cautions = [];
    world.actions = [];
    world.timeline = [];
    world.text = [];
    world.cycle = 0;
    world.lastUpdated = 0;
    world.telemetry = {
        averageConfidence: 0,
        averageImportance: 0,
        signalStrength: 0,
        motionScore: 0
    };
    world.context = {
        scenario: elements.scenarioInput?.value?.trim() || "",
        mode: visionAgent.screenMode ? "screen" : "webpage"
    };
    uiState.selectedNodeId = "";
    if (elements.chatMessages) {
        elements.chatMessages.innerHTML = "";
    }
    appendChatMessage("observer", "Observer AO reset. Add a mission, run a cycle, or enable full-screen vision to start rebuilding the model.");
    render();
    persistSnapshot();
}

function createTimelineItem(type, title, detail) {
    return {
        id: `${type}-${crypto.randomUUID()}`,
        type,
        title,
        detail,
        time: new Date().toISOString()
    };
}

function pushTimelineFromWorld() {
    const items = [];

    for (const event of world.events.slice(0, 6)) {
        const detailParts = Object.entries(event.data || {}).slice(0, 3).map(([key, value]) => `${key}: ${value}`);
        items.push(createTimelineItem("event", event.type, detailParts.join(" · ") || "Architectural signal observed."));
    }

    if (world.memories[0]?.summary?.headline) {
        items.push(createTimelineItem("memory", "Memory snapshot stored", world.memories[0].summary.headline));
    }

    if (world.goals[0]) {
        items.push(createTimelineItem("goal", world.goals[0].title, world.goals[0].rationale));
    }

    world.timeline = [...items, ...world.timeline].slice(0, MAX_TIMELINE);
}

function getRecentChatSeed() {
    if (!elements.chatMessages) return [];
    return [...elements.chatMessages.querySelectorAll(".chat-msg")].slice(-8).map((node) => ({
        role: node.dataset.role || "observer",
        text: node.dataset.text || node.textContent || ""
    }));
}

function appendChatMessage(role, text, persist = true) {
    if (!elements.chatMessages) return;
    const item = document.createElement("div");
    item.className = `chat-msg ${role === "user" ? "chat-msg-user" : "chat-msg-observer"}`;
    item.dataset.role = role;
    item.dataset.text = text;
    item.innerHTML = `
        <div class="chat-msg-role">${role === "user" ? "Operator" : "Observer AO"}</div>
        <div class="chat-msg-body">${escapeHtml(text)}</div>
    `;
    elements.chatMessages.appendChild(item);
    elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
    if (persist) persistSnapshot();
}

function summarizeWorld() {
    const topConcepts = world.concepts.slice(0, 4).map((item) => item.name).join(", ") || "no stable concepts yet";
    const topPattern = world.patterns[0]?.name || "no dominant pattern";
    const topGoal = world.goals[0]?.title || "continue observation";
    return `I currently see ${world.objects.length} objects, ${world.events.length} events this cycle, and ${world.memories.length} persisted memories. Top concepts: ${topConcepts}. Strongest pattern: ${topPattern}. Recommended next focus: ${topGoal}.`;
}

function generateObserverReply(input) {
    const text = input.toLowerCase();

    if (text.includes("what") && (text.includes("see") || text.includes("observe"))) {
        return summarizeWorld();
    }

    if (text.includes("architecture") || text.includes("system") || text.includes("structure")) {
        const thought = world.thoughts[0]?.message || "The architectural picture is still emerging.";
        const pattern = world.patterns[0]?.description || "No repeated structure dominates yet.";
        return `${thought} ${pattern}`;
    }

    if (text.includes("next") || text.includes("action") || text.includes("do")) {
        return world.actions.length > 0
            ? `Recommended actions: ${world.actions.join(" ")}`
            : "I need another analysis cycle before recommending concrete actions.";
    }

    if (text.includes("risk") || text.includes("skeptic") || text.includes("uncertain")) {
        return world.cautions.length > 0
            ? `Current cautions: ${world.cautions.join(" ")}`
            : "No major cautions at the moment, but conclusions remain provisional until more evidence arrives.";
    }

    if (text.includes("goal") || text.includes("priority")) {
        return world.goals.length > 0
            ? `Top goal: ${world.goals[0].title}. Reason: ${world.goals[0].rationale}`
            : "No active goal has been synthesized yet.";
    }

    if (text.includes("mission") || text.includes("scenario")) {
        return world.context.scenario
            ? `Current mission brief: ${world.context.scenario}`
            : "No mission brief is set yet. Use the Mission Brief panel to guide the observer.";
    }

    return `${summarizeWorld()} Ask about architecture, goals, risks, or next actions for a more targeted answer.`;
}

function renderMetric(idNode, value) {
    if (idNode) idNode.textContent = String(value);
}

function renderList(target, entries, fallbackText, formatter) {
    if (!target) return;
    target.innerHTML = "";

    if (!entries || entries.length === 0) {
        const li = document.createElement("li");
        li.innerHTML = `<span class="item-title">${escapeHtml(fallbackText)}</span>`;
        target.appendChild(li);
        return;
    }

    for (const entry of entries) {
        const li = document.createElement("li");
        const { title, subtle } = formatter(entry);
        li.innerHTML = `<span class="item-title">${escapeHtml(title)}</span>${subtle ? `<span class="item-subtle">${escapeHtml(subtle)}</span>` : ""}`;
        target.appendChild(li);
    }
}

function renderTimeline() {
    if (!elements.timelineList) return;
    elements.timelineList.innerHTML = "";

    for (const item of world.timeline) {
        const row = document.createElement("div");
        row.className = "timeline-item";
        row.innerHTML = `
            <div class="timeline-title">${escapeHtml(item.title)}</div>
            <div class="timeline-body">${escapeHtml(item.detail)}</div>
            <div class="timeline-meta">${new Date(item.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · ${escapeHtml(item.type)}</div>
        `;
        elements.timelineList.appendChild(row);
    }
}

function ensureSelectedNode(nodes) {
    if (!nodes.length) {
        uiState.selectedNodeId = "";
        return null;
    }

    const selected = nodes.find((node) => node.id === uiState.selectedNodeId);
    if (selected) return selected;

    const fallback = nodes[0];
    uiState.selectedNodeId = fallback.id;
    return fallback;
}

function updateInspector(node) {
    if (!node) {
        if (elements.selectedNodeLabel) elements.selectedNodeLabel.textContent = "None";
        if (elements.selectedNodeType) elements.selectedNodeType.textContent = "—";
        if (elements.selectedNodeDetail) elements.selectedNodeDetail.textContent = "Choose a node to inspect the current architectural story.";
        return;
    }

    if (elements.selectedNodeLabel) elements.selectedNodeLabel.textContent = node.label;
    if (elements.selectedNodeType) elements.selectedNodeType.textContent = node.kind;
    if (elements.selectedNodeDetail) elements.selectedNodeDetail.textContent = node.detail;
}

function renderGraph() {
    const svg = elements.graphSvg;
    if (!svg) return;
    svg.innerHTML = "";

    const nodes = [];
    const links = [];

    const scenarioLabel = world.context.scenario ? compactText(world.context.scenario, 46) : "No mission brief";
    nodes.push({ id: "scenario", label: "Mission", kind: "scenario", detail: scenarioLabel, x: 160, y: 80, color: "#59dfd4" });

    const conceptNodes = world.concepts.slice(0, 4).map((item, index) => ({
        id: item.id,
        label: compactText(item.name, 18),
        kind: "concept",
        detail: `${item.description}. Score ${item.score}.`,
        x: 360,
        y: 70 + (index * 88),
        color: "#8df6a6"
    }));

    const patternNodes = world.patterns.slice(0, 3).map((item, index) => ({
        id: item.id,
        label: compactText(item.name, 18),
        kind: "pattern",
        detail: `${item.description} Score ${item.score}.`,
        x: 585,
        y: 110 + (index * 110),
        color: "#ffd66d"
    }));

    const memoryNodes = world.memories.slice(0, 3).map((item, index) => ({
        id: item.id,
        label: `M${index + 1}`,
        kind: "memory",
        detail: item.summary?.headline || "Memory snapshot",
        x: 785,
        y: 100 + (index * 110),
        color: "#9fd0ff"
    }));

    const goalNodes = world.goals.slice(0, 2).map((item, index) => ({
        id: item.id,
        label: compactText(item.title, 18),
        kind: "goal",
        detail: item.rationale,
        x: 815,
        y: 330 + (index * 56),
        color: "#ff7e6f"
    }));

    nodes.push(...conceptNodes, ...patternNodes, ...memoryNodes, ...goalNodes);

    for (const node of conceptNodes) {
        links.push(["scenario", node.id]);
    }
    for (let index = 0; index < Math.min(conceptNodes.length, patternNodes.length); index += 1) {
        links.push([conceptNodes[index].id, patternNodes[index].id]);
    }
    for (const patternNode of patternNodes) {
        if (memoryNodes[0]) links.push([patternNode.id, memoryNodes[0].id]);
    }
    for (const memoryNode of memoryNodes) {
        if (goalNodes[0]) links.push([memoryNode.id, goalNodes[0].id]);
    }
    if (goalNodes[1] && patternNodes[1]) {
        links.push([patternNodes[1].id, goalNodes[1].id]);
    }

    const nodeMap = new Map(nodes.map((node) => [node.id, node]));
    const selected = ensureSelectedNode(nodes);

    for (const [fromId, toId] of links) {
        const from = nodeMap.get(fromId);
        const to = nodeMap.get(toId);
        if (!from || !to) continue;
        const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
        line.setAttribute("x1", String(from.x));
        line.setAttribute("y1", String(from.y));
        line.setAttribute("x2", String(to.x));
        line.setAttribute("y2", String(to.y));
        line.setAttribute("class", "edge-line");
        svg.appendChild(line);
    }

    for (const node of nodes) {
        const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
        const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
        const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
        circle.setAttribute("cx", String(node.x));
        circle.setAttribute("cy", String(node.y));
        circle.setAttribute("r", node.kind === "scenario" ? "40" : node.kind === "goal" ? "34" : "30");
        circle.setAttribute("fill", node.color);
        circle.setAttribute("fill-opacity", node.id === selected?.id ? "0.95" : "0.82");
        circle.setAttribute("stroke", node.id === selected?.id ? "#ffffff" : "rgba(255,255,255,0.08)");
        circle.setAttribute("class", `node-shape ${node.id === selected?.id ? "selected" : ""}`);
        circle.dataset.nodeId = node.id;
        text.setAttribute("x", String(node.x));
        text.setAttribute("y", String(node.y + 4));
        text.setAttribute("class", "node-label");
        text.textContent = node.label;

        group.appendChild(circle);
        group.appendChild(text);
        group.addEventListener("click", () => {
            uiState.selectedNodeId = node.id;
            updateInspector(node);
            renderGraph();
            persistSnapshot();
        });
        svg.appendChild(group);
    }

    updateInspector(selected);
}

function renderAgentLanes() {
    if (!elements.agentLanes) return;
    elements.agentLanes.innerHTML = "";

    for (const lane of laneDefinitions) {
        const card = document.createElement("div");
        card.className = "agent-lane";
        card.dataset.agentCard = lane.key;
        card.innerHTML = `
            <span class="lane-chip">${escapeHtml(lane.label)}</span>
            <strong>${escapeHtml(lane.source())}</strong>
            <div class="lane-meta">${escapeHtml(lane.description)}</div>
        `;
        elements.agentLanes.appendChild(card);
    }
}

function render() {
    renderMetric(elements.objectsCount, world.objects.length);
    renderMetric(elements.eventsCount, world.events.length);
    renderMetric(elements.memoriesCount, world.memories.length);
    renderMetric(elements.conceptsCount, world.concepts.length);
    renderMetric(elements.thoughtsCount, world.thoughts.length);
    renderMetric(elements.goalsCount, world.goals.length);

    if (elements.modeBadge) elements.modeBadge.textContent = world.context.mode === "screen" ? "Full Screen" : "Webpage";
    if (elements.cycleBadge) elements.cycleBadge.textContent = String(world.cycle);
    if (elements.signalBadge) elements.signalBadge.textContent = String(world.telemetry.signalStrength || 0);

    renderList(elements.objectsList, world.objects.slice(0, 14), "No objects visible yet", (item) => ({
        title: item.properties.text || item.type,
        subtle: `${item.type}${item.properties.id ? ` · #${item.properties.id}` : ""}${item.properties.className ? ` · ${compactText(item.properties.className, 26)}` : ""}`
    }));

    renderList(elements.eventsList, world.events.slice(0, 12), "No events captured in this cycle", (item) => ({
        title: item.type,
        subtle: Object.entries(item.data || {}).slice(0, 3).map(([key, value]) => `${key}: ${value}`).join(" · ") || "Event data unavailable"
    }));

    renderList(elements.memoriesList, world.memories.slice(0, 10), "No memories stored yet", (item) => ({
        title: item.summary?.headline || "Memory snapshot",
        subtle: `importance ${item.importance} · confidence ${item.confidence} · ${(item.summary?.events || []).join(", ") || "no notable events"}`
    }));

    renderList(elements.conceptsList, world.concepts.slice(0, 12), "No concepts formed yet", (item) => ({
        title: item.name,
        subtle: `score ${item.score} · ${item.description}`
    }));

    renderList(elements.patternsList, world.patterns.slice(0, 10), "No patterns found yet", (item) => ({
        title: item.name,
        subtle: `score ${item.score} · ${item.description}`
    }));

    renderList(elements.goalsList, world.goals.slice(0, 8), "No goals synthesized yet", (item) => ({
        title: item.title,
        subtle: `${item.status} · priority ${item.priority} · ${item.rationale}`
    }));

    renderList(elements.actionsList, world.actions, "No actions recommended yet", (item) => ({
        title: item,
        subtle: "Action derived from current reasoning state"
    }));

    renderTimeline();
    renderGraph();
    renderAgentLanes();
}

function runCycle() {
    world.context.scenario = elements.scenarioInput?.value?.trim() || world.context.scenario || "";
    world.events = [];
    world.lastUpdated = Date.now();
    world.cycle += 1;

    for (const agent of agents) {
        agent.update(world);
    }

    pushTimelineFromWorld();
    render();
    persistSnapshot();
}

function setAutoCycle(enabled) {
    if (enabled && !uiState.autoTimer) {
        uiState.autoTimer = window.setInterval(runCycle, 2500);
        if (elements.autoCycleBtn) elements.autoCycleBtn.textContent = "Stop Auto Cycle";
        setVisionStatus("Auto cycle active. Observer AO is refreshing every 2.5 seconds.");
        return;
    }

    if (!enabled && uiState.autoTimer) {
        window.clearInterval(uiState.autoTimer);
        uiState.autoTimer = null;
        if (elements.autoCycleBtn) elements.autoCycleBtn.textContent = "Start Auto Cycle";
        setVisionStatus(world.context.mode === "screen"
            ? "Auto cycle stopped. Full-screen vision remains available."
            : "Auto cycle stopped. Vision source: webpage.");
    }
}

if (elements.loadSampleBtn) {
    elements.loadSampleBtn.addEventListener("click", () => {
        if (elements.scenarioInput) {
            elements.scenarioInput.value = sampleMission();
        }
        world.context.scenario = sampleMission();
        appendChatMessage("observer", "Sample mission loaded. Run an analysis cycle to generate a fresh architectural interpretation.");
        persistSnapshot();
    });
}

if (elements.runCycleBtn) {
    elements.runCycleBtn.addEventListener("click", runCycle);
}

if (elements.autoCycleBtn) {
    elements.autoCycleBtn.addEventListener("click", () => {
        setAutoCycle(!uiState.autoTimer);
    });
}

if (elements.clearBtn) {
    elements.clearBtn.addEventListener("click", resetPrototype);
}

if (elements.startScreenVisionBtn) {
    elements.startScreenVisionBtn.addEventListener("click", async () => {
        try {
            setVisionStatus("Requesting screen permission…");
            await visionAgent.startScreenCapture();
            const info = visionAgent.getVisionInfo();
            world.context.mode = "screen";
            if (info.displaySurface !== "monitor") {
                setVisionStatus(`Vision active, but surface is ${info.displaySurface}. Select Entire Screen for complete architectural coverage.`);
            } else {
                setVisionStatus(`Vision source: full screen (${info.width}×${info.height}, ${info.pointCount} sample points).`);
            }
            runCycle();
        } catch (error) {
            setVisionStatus(`Screen capture failed: ${error.message}`);
        }
    });
}

if (elements.stopScreenVisionBtn) {
    elements.stopScreenVisionBtn.addEventListener("click", () => {
        visionAgent.stopScreenCapture();
        world.context.mode = "webpage";
        setVisionStatus("Vision source: webpage. Screen capture has been stopped.");
        runCycle();
    });
}

if (elements.checkVisionBtn) {
    elements.checkVisionBtn.addEventListener("click", () => {
        const info = visionAgent.getVisionInfo();
        if (!info.screenMode) {
            setVisionStatus("Vision check: not in full-screen mode. Enable screen vision to broaden the observer's field of view.");
            return;
        }
        if (info.displaySurface !== "monitor") {
            setVisionStatus(`Vision check: active, but the selected surface is ${info.displaySurface}. Entire Screen is recommended.`);
            return;
        }
        setVisionStatus(`Vision check: full-screen OK at ${info.width}×${info.height} with ${info.pointCount} sampled points and motion score ${info.motionScore}.`);
    });
}

if (elements.exportMemoriesBtn) {
    elements.exportMemoriesBtn.addEventListener("click", exportSnapshot);
}

if (elements.importMemoriesBtn && elements.importMemoriesInput) {
    elements.importMemoriesBtn.addEventListener("click", () => elements.importMemoriesInput.click());
    elements.importMemoriesInput.addEventListener("change", async () => {
        const [file] = elements.importMemoriesInput.files || [];
        if (!file) return;
        try {
            await importSnapshot(file);
        } catch {
            setVisionStatus("Import failed. Please choose a valid Observer AO snapshot JSON file.");
        } finally {
            elements.importMemoriesInput.value = "";
        }
    });
}

function handleChatSend() {
    const value = elements.chatInput?.value?.trim();
    if (!value) return;
    appendChatMessage("user", value);
    appendChatMessage("observer", generateObserverReply(value));
    elements.chatInput.value = "";
}

if (elements.sendChatBtn) {
    elements.sendChatBtn.addEventListener("click", handleChatSend);
}

if (elements.chatInput) {
    elements.chatInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            handleChatSend();
        }
    });
}

const restored = loadSnapshot();
if (restored) {
    mergeImportedSnapshot(restored);
}

if (!elements.scenarioInput?.value) {
    elements.scenarioInput.value = world.context.scenario || sampleMission();
    if (!world.context.scenario) {
        world.context.scenario = elements.scenarioInput.value;
    }
}

window.observerWorld = world;
appendChatMessage("observer", "Observer AO online. The prototype now surfaces its objects, events, memories, concepts, patterns, goals, and actions directly in the interface.", false);
runCycle();
