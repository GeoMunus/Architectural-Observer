export default class Planner {

    createPlan(goal) {

        switch (goal.type) {

            case "identify":

                return [

                    "look",

                    "analyze",

                    "compare",

                    "store"

                ];

            case "helpUser":

                return [

                    "understand",

                    "reason",

                    "respond"

                ];

            case "resolveConflict":

                return [

                    "compareBeliefs",

                    "evaluateEvidence",

                    "updateBelief"

                ];

            default:

                return [];

        }

    }

}